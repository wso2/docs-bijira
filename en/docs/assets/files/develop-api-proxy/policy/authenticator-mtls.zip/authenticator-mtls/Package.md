# MTLS Authenticator

## Overview

This policy enables MTLS security for the API.

## Usage

This will be available to select when attaching mediation policies to a proxy in Choreo. The following policy parameters are available:
- `Certificate content`: the client certificate content
- `optional`: Whether mtls is optional or not. If selected, only validate if the certificate is available.



## Build java component

#### Generate .class files 

```
javac com/wso2/choreo/am/mediation/certificates/CertificateValidator.java  com/wso2/choreo/am/mediation/certificates/ValidationResponse.java
```

#### Generate jar file

```
jar -cvf <path>/authenticator-mtls/libs/certificate-validator.jar <path>/authenticator-mtls/com/wso2/choreo/am/mediation/certificates/CertificateValidator.class  <path>/authenticator-mtls/com/wso2/choreo/am/mediation/certificates/ValidationResponse.class
```

#### Bindgen

```
bal bindgen -cp ./libs/certificate-validator.jar com.wso2.choreo.am.mediation.certificates.CertificateValidator com.wso2.choreo.am.mediation.certificates.ValidationResponse
```